--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP INDEX public.watchables_search_idx;
DROP INDEX public.index_watchables_on_tmdb_type;
DROP INDEX public.index_watchables_on_tmdb_id_and_tmdb_type;
ALTER TABLE ONLY public.watchables DROP CONSTRAINT watchables_pkey;
ALTER TABLE ONLY public.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY public.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE public.watchables ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.watchables_id_seq;
DROP TABLE public.watchables;
DROP TABLE public.schema_migrations;
DROP TABLE public.ar_internal_metadata;
DROP EXTENSION pg_trgm;
DROP EXTENSION btree_gin;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE schema_migrations (
    version character varying NOT NULL
);


--
-- Name: watchables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE watchables (
    id integer NOT NULL,
    tmdb_id integer NOT NULL,
    tmdb_type character varying NOT NULL,
    title character varying NOT NULL,
    hulu character varying,
    amazon character varying,
    netflix character varying,
    xfinity character varying,
    amazon_buy character varying,
    google_play character varying,
    itunes character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    poster character varying
);


--
-- Name: watchables_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE watchables_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: watchables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE watchables_id_seq OWNED BY watchables.id;


--
-- Name: watchables id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY watchables ALTER COLUMN id SET DEFAULT nextval('watchables_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/2560.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/2559.dat';

--
-- Data for Name: watchables; Type: TABLE DATA; Schema: public; Owner: -
--

COPY watchables (id, tmdb_id, tmdb_type, title, hulu, amazon, netflix, xfinity, amazon_buy, google_play, itunes, created_at, updated_at, poster) FROM stdin;
\.
COPY watchables (id, tmdb_id, tmdb_type, title, hulu, amazon, netflix, xfinity, amazon_buy, google_play, itunes, created_at, updated_at, poster) FROM '$$PATH$$/2562.dat';

--
-- Name: watchables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('watchables_id_seq', 22255, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: watchables watchables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY watchables
    ADD CONSTRAINT watchables_pkey PRIMARY KEY (id);


--
-- Name: index_watchables_on_tmdb_id_and_tmdb_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_watchables_on_tmdb_id_and_tmdb_type ON watchables USING btree (tmdb_id, tmdb_type);


--
-- Name: index_watchables_on_tmdb_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_watchables_on_tmdb_type ON watchables USING btree (tmdb_type);


--
-- Name: watchables_search_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watchables_search_idx ON watchables USING gin (title gin_trgm_ops);


--
-- PostgreSQL database dump complete
--

